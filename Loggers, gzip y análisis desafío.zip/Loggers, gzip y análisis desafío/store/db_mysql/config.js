const config = {
  client: 'mysql',
  connection: {
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'products',
  },
}

module.exports = {
  config,
}
