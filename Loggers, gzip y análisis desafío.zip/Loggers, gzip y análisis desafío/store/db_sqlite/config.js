const config = {
  client: 'sqlite3',
  connection: './db/mydb.sqlite',
  useNullAsDefault: true,
}

module.exports = {
  config,
}
