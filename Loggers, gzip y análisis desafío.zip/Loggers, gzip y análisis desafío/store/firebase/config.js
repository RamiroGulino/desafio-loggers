const config = {
  FIREBASE_KEY: JSON.parse(process.env.FIREBASE_KEY),
}

module.exports = {
  config,
}
